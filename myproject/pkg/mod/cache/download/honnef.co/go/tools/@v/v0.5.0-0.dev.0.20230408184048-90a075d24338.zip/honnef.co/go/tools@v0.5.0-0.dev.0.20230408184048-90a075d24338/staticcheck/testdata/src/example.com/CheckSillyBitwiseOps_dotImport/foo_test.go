package foo_test

import . "example.com/CheckSillyBitwiseOps_dotImport"

var _ = 1 | X
